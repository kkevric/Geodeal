<?php
// To
define("WEBMASTER_EMAIL", 'katja.kevric@geodeal.si');
?>